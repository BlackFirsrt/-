package carGame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.geom.Line2D;

import javax.swing.JFrame;
import javax.swing.JPanel;

/*
 * ��ʼ��Ϸ��Ľ��棺
 * 			�У�������Բ�����Σ�
 * 					��������ʱһ�����������߳�50
 * 					�������ϰ����ʱһ�֣�����70����260
 * 					
 * 
 */
public class Game_ extends JFrame{
	
	private static final int HEIGHT  = 600, WIDTH = 600;
	private static final int RECT_HEIGHT = 260, RECT_WIDTH = 40;
	private final int CAR_LENGTH = 20;//��������
	private double p1_speed = .5,p2_speed = .5;//Ĭ���ٶ�
	private final int UP = 0, RIGHT = 1, DOWN = 2, LEFT = 3;
	private int p1_Direction = UP,p2_Direction = UP;//����Ĭ�Ϸ�������
	//�������Ϊ���Ƴ����ϰ���
	Rectangle RECT_Left = new Rectangle(0, 0,10, HEIGHT);
	Rectangle RECT_Rright = new Rectangle(WIDTH, 0,10, HEIGHT);
	Rectangle RECT_Up = new Rectangle(0, 0,WIDTH, 10);
	Rectangle RECT_Down = new Rectangle(0, HEIGHT,WIDTH, 10);
	Rectangle obstacle_1 = new Rectangle(0, HEIGHT-RECT_HEIGHT, RECT_WIDTH, RECT_HEIGHT);
	Rectangle obstacle_2 = new Rectangle((WIDTH-RECT_WIDTH)*1/2, 0, RECT_WIDTH, RECT_HEIGHT*3/4);
	Rectangle obstacle_3 = new Rectangle((WIDTH-RECT_HEIGHT)*1/2, HEIGHT-RECT_HEIGHT-RECT_WIDTH, RECT_HEIGHT, RECT_WIDTH);
	Rectangle obstacle_4 = new Rectangle((WIDTH-RECT_HEIGHT)*1/2-RECT_WIDTH, HEIGHT-RECT_HEIGHT, RECT_WIDTH, RECT_HEIGHT*1/4);
	Rectangle obstacle_5 = new Rectangle((WIDTH-RECT_HEIGHT)*1/2-RECT_WIDTH, HEIGHT-RECT_HEIGHT*1/2, RECT_WIDTH, RECT_HEIGHT*1/2);
	Rectangle obstacle_6 = new Rectangle((WIDTH-RECT_WIDTH)*1/2, HEIGHT-RECT_HEIGHT*4/5, RECT_WIDTH, RECT_HEIGHT*4/5);	
	Rectangle obstacle_7 = new Rectangle((WIDTH-RECT_HEIGHT)*1/2-RECT_WIDTH+RECT_HEIGHT, HEIGHT-RECT_HEIGHT, RECT_WIDTH, RECT_HEIGHT*2/3);
	Rectangle obstacle_8 = new Rectangle(WIDTH*1/10,HEIGHT*3/10, RECT_WIDTH*4, RECT_HEIGHT*1/2);
	Rectangle obstacle_9 = new Rectangle(WIDTH-WIDTH*2/5,HEIGHT*3/10, RECT_WIDTH*4, RECT_HEIGHT*1/2);	
	Rectangle obstacle_10 = new Rectangle(WIDTH*4/5, HEIGHT*4/5-RECT_HEIGHT*1/2, RECT_WIDTH, RECT_HEIGHT);	
	//������WIDTH-RECT_WIDTH
	Rectangle p1 = new Rectangle((WIDTH-RECT_WIDTH)*1/8-CAR_LENGTH, HEIGHT*9/10, CAR_LENGTH,CAR_LENGTH);
	Rectangle p2 = new Rectangle((WIDTH-RECT_WIDTH)*1/8+CAR_LENGTH, HEIGHT*9/10, CAR_LENGTH,CAR_LENGTH);
	
	public Game_() {
		this.setTitle("���龺��");
		this.setSize(600, 600);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);
		this.setVisible(true);
		this.setResizable(false);//���ô��ڴ�С������
		this.setLocationRelativeTo(null);
		
		Move1 m1 = new Move1();
		Move2 m2 = new Move2();
		m1.start();
		m2.start();
	}
	public void paint(Graphics g) {
		g.clearRect(0, 0, WIDTH, HEIGHT);//���ָ���ռ��ڵ�����
		g.setColor(Color.GREEN);
		g.fillRect(0, 0, 600, 600);
		//����ռ��е����ݣ���ɫ�������
		g.setColor(Color.BLACK);
		g.drawRect(0, 0,WIDTH, HEIGHT);
		g.fillRect(0, HEIGHT-RECT_HEIGHT, RECT_WIDTH, RECT_HEIGHT);
		g.fillRect((WIDTH-RECT_WIDTH)*1/2, 0, RECT_WIDTH, RECT_HEIGHT*3/4);
		g.fillRect((WIDTH-RECT_HEIGHT)*1/2, HEIGHT-RECT_HEIGHT-RECT_WIDTH, RECT_HEIGHT, RECT_WIDTH);
		g.fillRect((WIDTH-RECT_HEIGHT)*1/2-RECT_WIDTH, HEIGHT-RECT_HEIGHT, RECT_WIDTH, RECT_HEIGHT*1/4);
		g.fillRect((WIDTH-RECT_HEIGHT)*1/2-RECT_WIDTH, HEIGHT-RECT_HEIGHT*1/2, RECT_WIDTH, RECT_HEIGHT*1/2);
		g.fillRect((WIDTH-RECT_WIDTH)*1/2, HEIGHT-RECT_HEIGHT*4/5, RECT_WIDTH, RECT_HEIGHT*4/5);
		g.fillRect((WIDTH-RECT_HEIGHT)*1/2-RECT_WIDTH+RECT_HEIGHT, HEIGHT-RECT_HEIGHT, RECT_WIDTH, RECT_HEIGHT*2/3);
		g.fillOval(WIDTH*1/10,HEIGHT*3/10, RECT_WIDTH*4, RECT_HEIGHT*1/2);
		g.fillOval(WIDTH-WIDTH*2/5,HEIGHT*3/10, RECT_WIDTH*4, RECT_HEIGHT*1/2);
		g.fillRect(WIDTH*4/5, HEIGHT*4/5-RECT_HEIGHT*1/2, RECT_WIDTH, RECT_HEIGHT);
		g.setColor(Color.red);
		g.drawLine(WIDTH*4/5, 0, WIDTH, HEIGHT*1/5);
		g.drawString("�յ�", WIDTH*9/10, HEIGHT*1/12);
		//������
		g.setColor(Color.BLUE);
		g.fillRect(p1.x, p1.y, p1.width, p1.width);
		g.fillRect(p2.x, p2.y, p2.width, p2.width);
		
	}
	private void p1_insert() {
		if (p1.intersects(RECT_Up)||p1.intersects(RECT_Rright)||p1.intersects(RECT_Left)||p1.intersects(RECT_Down)||p1.intersects(obstacle_1)||
				p1.intersects(obstacle_2)||p1.intersects(obstacle_3)||
				p1.intersects(obstacle_4)||p1.intersects(obstacle_5)||
				p1.intersects(obstacle_6)||p1.intersects(obstacle_7)||
				p1.intersects(obstacle_8)||p1.intersects(obstacle_9)||
				p1.intersects(obstacle_10)) {
			p1_speed = 0;
			if(p1_Direction==UP)
				p1.y += 5;
			if(p1_Direction==DOWN) 
				p1.y -= 5;
			if(p1_Direction==LEFT) 
				p1.x += 5;
			if(p1_Direction==RIGHT) 
				p1.x -= 5;
		}
	}
	private void p2_insert() {
		if (p2.intersects(RECT_Up)||p2.intersects(RECT_Rright)||
				p2.intersects(RECT_Left)||p2.intersects(RECT_Down)||p2.intersects(obstacle_1)||
				p2.intersects(obstacle_2)||p2.intersects(obstacle_3)||
				p2.intersects(obstacle_4)||p2.intersects(obstacle_5)||
				p2.intersects(obstacle_6)||p2.intersects(obstacle_7)||
				p2.intersects(obstacle_8)||p2.intersects(obstacle_9)||
				p2.intersects(obstacle_10)) {
			p2_speed = 0;
			if(p2_Direction==UP) 
				p2.y += 5;
			if(p2_Direction==DOWN) 
				p2.y -= 5;
			if(p2_Direction==LEFT) 
				p2.x += 5;
			if(p2_Direction==RIGHT) 
				p2.x -= 5;
		}
	}
	private class Move1 extends Thread implements KeyListener {
		@Override
		public void run() {
			addKeyListener(this);
			//����ͨ��ѭ�����ʹ��������ǰ��
			while(true) {
				//����try...catch��䲶׽�쳣��
				try {//ˢ����Ļ
					repaint();
					//�������ײ��������ǽ�����ϰ���ٶ��𽥼�����Ϊ0
					p1_insert();
					//���������в��ϼ��٣��ٶ����ֵΪ5
					if(p1_speed<=5) {
						p1_speed += .5;
					}
					//���̿�����������
					if(p1_Direction == UP) {
						p1_insert();
						p1.y -= (int)p1_speed;
					}
					if(p1_Direction == DOWN) {
						p1_insert();
						p1.y += (int)p1_speed;
					}
					if(p1_Direction == LEFT) {
						p1_insert();
						p1.x -= (int)p1_speed;
					}
					if(p1_Direction == RIGHT) {
						p1_insert();
						p1.x += (int)p1_speed;
					}
					//����ÿ����ǰ��ʱ����Ϊ0.1��
					Thread.sleep(50);
					} catch (Exception e) {
					break;
				}
			}
		}
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub			
		}
		@Override
		public void keyReleased(KeyEvent e) {
			if(e.getKeyChar() == 'w') {
				p1_Direction = UP;
			}
			if(e.getKeyChar() == 's') {
				p1_Direction = DOWN;
			}
			if(e.getKeyChar() == 'a') {
				p1_Direction = LEFT;
			}
			if(e.getKeyChar() == 'd') {
				p1_Direction = RIGHT;
			}
		}
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
		}
	}private class Move2 extends Thread implements KeyListener {
		@Override
		public void run() {
			addKeyListener(this);
			//����ͨ��ѭ�����ʹ��������ǰ��
			while(true) {
				//����try...catch��䲶׽�쳣��
				try {//ˢ����Ļ
					repaint();
					//�������ײ��������ǽ�����ϰ���ٶ��𽥼�����Ϊ0
					p2_insert();
					//���������в��ϼ��٣��ٶ����ֵΪ5
					if(p2_speed<=5) {
						p2_insert();
						p2_speed += .5;
					}
					//���̿�����������
					if(p2_Direction == UP) {
						p2_insert();
						p2.y -= (int)p2_speed;
					}
					if(p2_Direction == DOWN) {
						p2_insert();
						p2.y += (int)p2_speed;
					}
					if(p2_Direction == LEFT) {
						p2_insert();
						p2.x -= (int)p2_speed;
					}
					if(p2_Direction == RIGHT) {
						p2_insert();
						p2.x += (int)p2_speed;
					}
					//����ÿ����ǰ��ʱ����Ϊ0.1��
					Thread.sleep(50);
					} catch (Exception e) {
					break;
				}
			}
		}
		@Override
		public void keyPressed(KeyEvent e) {
			// TODO Auto-generated method stub			
		}
		@Override
		public void keyReleased(KeyEvent e) {
			if(e.getKeyChar() == 'i') {
				p2_Direction = UP;
			}
			if(e.getKeyChar() == 'k') {
				p2_Direction = DOWN;
			}
			if(e.getKeyChar() == 'j') {
				p2_Direction = LEFT;
			}
			if(e.getKeyChar() == 'l') {
				p2_Direction = RIGHT;
			}
		}
		@Override
		public void keyTyped(KeyEvent e) {
			// TODO Auto-generated method stub
		}
	}
	public static void main(String[] args) {
		new Game_();
	}
}

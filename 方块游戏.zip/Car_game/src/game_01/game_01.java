package game_01;

import java.awt.Graphics;

import javax.swing.JFrame;

public class game_01 extends JFrame {
	public game_01() {
		super("title goes here");
		setSize(400,400);
		setLocationRelativeTo(null);
		setVisible(true);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void paint(Graphics g) {
		super.paint(g);
		g.drawRect(0, 0, 100, 200);
		g.fillRect(200, 200, 200, 200);
	}
	public static void main(String[] args) {
		new game_01();
	}
}
